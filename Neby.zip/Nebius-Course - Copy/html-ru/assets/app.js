/* Nebius course site – behaviour (vanilla JS, works from file://) */
(function () {
  "use strict";
  var doc = document.documentElement;
  var ROOT = document.body.getAttribute("data-root") || "";

  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  function $(sel, el) { return (el || document).querySelector(sel); }
  function $$(sel, el) { return Array.prototype.slice.call((el || document).querySelectorAll(sel)); }

  /* ---------------- interface strings ---------------- */
  var STR = {
    en: {
      narrow: "Narrow", wide: "Wide", full: "Full", copy: "Copy", copied: "Copied",
      offlineReady: "Offline ready: all {n} images are saved in this folder.",
      offlinePartial: "{k} of {n} images saved. ", offlineNone: "Images are not saved for offline reading yet. ",
      offlineHow: "While online, double-click <b>Download images for offline use.bat</b> in the html folder.",
      pickFirst: "Pick an answer first", answersShown: "Correct answers highlighted", answerShown: "Correct answer highlighted",
      correct: "Correct!", multiPartial: "{r} of {n} correct options selected", plusWrong: ", plus some wrong ones", tryAgain: ". Try again.",
      notQuite: "Not quite — try again.", pairsShown: "Correct pairs shown", notThis: "Not this one.",
      matchFirst: "Match at least one item first", allPairs: "All pairs correct!", xOfY: "{g} of {n} correct",
      notAnswered: " ({e} not answered)", filled: "Answers filled in", chooseFirst: "Choose at least one answer first",
      allCorrect: "All correct!", noIndex: "Search index could not be loaded.", noMatch: "No lessons match “{q}”."
    },
    ru: {
      narrow: "Узко", wide: "Широко", full: "Во всю ширину", copy: "Копировать", copied: "Скопировано",
      offlineReady: "Можно читать без интернета: все изображения ({n}) сохранены в папке html.",
      offlinePartial: "Сохранено изображений: {k} из {n}. ", offlineNone: "Изображения ещё не сохранены для чтения без интернета. ",
      offlineHow: "Пока есть интернет, дважды щёлкните <b>Download images for offline use.bat</b> в папке html.",
      pickFirst: "Сначала выберите ответ", answersShown: "Правильные ответы выделены", answerShown: "Правильный ответ выделен",
      correct: "Верно!", multiPartial: "Выбрано правильных вариантов: {r} из {n}", plusWrong: ", а также неверные", tryAgain: ". Попробуйте ещё раз.",
      notQuite: "Не совсем — попробуйте ещё раз.", pairsShown: "Показаны правильные пары", notThis: "Не подходит.",
      matchFirst: "Сначала сопоставьте хотя бы один пункт", allPairs: "Все пары верны!", xOfY: "Верно: {g} из {n}",
      notAnswered: " (без ответа: {e})", filled: "Ответы подставлены", chooseFirst: "Сначала выберите хотя бы один ответ",
      allCorrect: "Всё верно!", noIndex: "Не удалось загрузить поисковый индекс.", noMatch: "Ничего не найдено по запросу «{q}»."
    }
  };
  var LANG = STR[doc.getAttribute("lang")] ? doc.getAttribute("lang") : "en";
  function T(key, vars) {
    var s = STR[LANG][key];
    if (vars) Object.keys(vars).forEach(function (k) { s = s.split("{" + k + "}").join(vars[k]); });
    return s;
  }

  /* ---------------- "EN" marks on lessons that are not translated yet ---------------- */
  if (window.TR_DONE) {
    $$(".tag-en[data-key]").forEach(function (t) { if (window.TR_DONE.indexOf(t.getAttribute("data-key")) < 0) t.classList.add("show"); });
  }

  /* ---------------- RU / EN switch: open the same page (and section) in the other language ---------------- */
  function currentSection() {
    var heads = $$(".lesson-body h2[id], .lesson-body h3[id]").filter(function (h) { return h.getClientRects().length; });
    var cur = null;
    heads.forEach(function (h) { if (h.getBoundingClientRect().top < 140) cur = h; });
    return cur ? cur.id : "";
  }
  $$("[data-lang-switch]").forEach(function (a) {
    a.addEventListener("click", function () {
      var id = currentSection();
      a.href = a.href.split("#")[0] + (id ? "#" + id : "");
    });
  });

  /* ---------------- theme + width ---------------- */
  var WIDTHS = ["normal", "wide", "full"], WLABEL = { normal: T("narrow"), wide: T("wide"), full: T("full") };
  function setWidthLabel() { var l = $("#width-label"); if (l) l.textContent = WLABEL[doc.getAttribute("data-width")] || T("wide"); }
  setWidthLabel();

  document.addEventListener("click", function (e) {
    var t = e.target.closest("[data-act]");
    if (!t) return;
    var act = t.getAttribute("data-act");
    if (act === "theme") {
      var next = doc.getAttribute("data-theme") === "dark" ? "light" : "dark";
      doc.setAttribute("data-theme", next); store("nc-theme", next);
    } else if (act === "width") {
      var cur = WIDTHS.indexOf(doc.getAttribute("data-width")), w = WIDTHS[(cur + 1) % WIDTHS.length];
      doc.setAttribute("data-width", w); store("nc-width", w); setWidthLabel();
    } else if (act === "menu") {
      document.body.classList.toggle("nav-open");
    } else if (act === "reveal-all") {
      $$(".quiz").forEach(function (q) { quizAction(q, "reveal"); });
    } else if (act === "check" || act === "reveal" || act === "reset" || act === "submit-text") {
      var q = t.closest(".quiz"); if (q) quizAction(q, act);
    }
  });

  /* ---------------- sidebar: keep active lesson in view ---------------- */
  var activeLink = $(".side-lesson.active");
  if (activeLink) {
    var sb = $("#sidebar");
    var top = activeLink.offsetTop - sb.clientHeight / 3;
    sb.scrollTop = Math.max(0, top);
  }

  /* ---------------- copy buttons ---------------- */
  document.addEventListener("click", function (e) {
    var b = e.target.closest(".copy-btn"); if (!b) return;
    var code = b.closest(".code").querySelector("pre").innerText;
    function ok() { b.textContent = T("copied"); b.classList.add("done"); setTimeout(function () { b.textContent = T("copy"); b.classList.remove("done"); }, 1400); }
    if (navigator.clipboard && window.isSecureContext !== false) {
      navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
    } else { fallbackCopy(code); ok(); }
  });
  function fallbackCopy(text) {
    var ta = document.createElement("textarea"); ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (e) { } document.body.removeChild(ta);
  }

  /* ---------------- images: lightbox + broken image hint ---------------- */
  document.addEventListener("click", function (e) {
    var img = e.target.closest(".md-img");
    if (img && !img.classList.contains("broken")) {
      var box = document.createElement("div"); box.className = "lightbox";
      var big = document.createElement("img"); big.src = img.currentSrc || img.src; box.appendChild(big);
      box.addEventListener("click", function () { box.remove(); });
      document.body.appendChild(box);
      return;
    }
  });
  /* home page: how many images are saved locally for offline reading */
  var offline = $(".offline-status");
  if (offline) {
    var list = []; try { list = JSON.parse(offline.getAttribute("data-images") || "[]"); } catch (e) { }
    var loaded = 0, done = 0, txt = $(".offline-text", offline);
    var finish = function () {
      if (++done < list.length) return;
      if (loaded === list.length) {
        offline.classList.add("ok");
        txt.textContent = T("offlineReady", { n: list.length });
      } else {
        offline.classList.add(loaded ? "partial" : "missing");
        txt.innerHTML = (loaded ? T("offlinePartial", { k: loaded, n: list.length }) : T("offlineNone")) + T("offlineHow");
      }
    };
    if (!list.length) offline.hidden = true;
    list.forEach(function (src) { var im = new Image(); im.onload = function () { loaded++; finish(); }; im.onerror = finish; im.src = ROOT + src; });
  }

  /* ---------------- TOC scrollspy ---------------- */
  var tocLinks = $$(".toc a");
  if (tocLinks.length && "IntersectionObserver" in window) {
    var map = {}, visible = {};
    tocLinks.forEach(function (a) { map[decodeURIComponent(a.getAttribute("href").slice(1))] = a; });
    var heads = Object.keys(map).map(function (id) { return document.getElementById(id); }).filter(Boolean);
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { visible[en.target.id] = en.isIntersecting; });
      var first = heads.find(function (h) { return visible[h.id]; });
      if (!first) {
        var above = heads.filter(function (h) { return h.getBoundingClientRect().top < 120; });
        first = above[above.length - 1];
      }
      tocLinks.forEach(function (a) { a.classList.remove("active"); });
      if (first && map[first.id]) map[first.id].classList.add("active");
    }, { rootMargin: "-60px 0px -60% 0px" });
    heads.forEach(function (h) { io.observe(h); });
  }

  /* ---------------- checklists (remembered in this browser) ---------------- */
  $$(".checklist input[data-key]").forEach(function (cb) {
    var k = "nc-chk-" + cb.getAttribute("data-key");
    if (store(k) === "1") cb.checked = true;
    cb.addEventListener("change", function () { store(k, cb.checked ? "1" : "0"); });
  });

  /* ---------------- quizzes ---------------- */
  function verdict(q, text, good) {
    var v = $(".quiz-verdict", q); if (!v) return;
    v.textContent = text; v.className = "quiz-verdict " + (good === true ? "ok" : good === false ? "bad" : "");
  }

  function quizAction(q, act) {
    if (q.classList.contains("quiz-select")) return selectQuiz(q, act);
    if (q.classList.contains("quiz-match")) return matchQuiz(q, act);
    if (q.classList.contains("quiz-blanks")) return blanksQuiz(q, act);
    if (act === "submit-text" && q.classList.contains("quiz-text")) q.classList.add("submitted");
  }

  function selectQuiz(q, act) {
    var opts = $$(".opt", q), multi = q.getAttribute("data-multi") === "1", showAll = q.getAttribute("data-showall") === "1";
    opts.forEach(function (o) { o.classList.remove("is-correct", "is-wrong", "is-answer", "show-fb"); });
    q.classList.remove("solved", "revealed");
    if (act === "reset") { $$("input", q).forEach(function (i) { i.checked = false; }); verdict(q, ""); return; }
    if (act === "reveal") {
      opts.forEach(function (o) {
        var c = o.getAttribute("data-correct") === "1", inp = $("input", o);
        if (c) o.classList.add("is-correct");
        if (c || showAll || inp.checked) o.classList.add("show-fb");
        inp.checked = c;
      });
      q.classList.add("revealed"); verdict(q, multi ? T("answersShown") : T("answerShown"), true);
      return;
    }
    var chosen = opts.filter(function (o) { return $("input", o).checked; });
    if (!chosen.length) { verdict(q, T("pickFirst")); return; }
    var allRight = opts.every(function (o) { return (o.getAttribute("data-correct") === "1") === $("input", o).checked; });
    chosen.forEach(function (o) {
      o.classList.add(o.getAttribute("data-correct") === "1" ? "is-correct" : "is-wrong", "show-fb");
    });
    if (showAll) opts.forEach(function (o) { o.classList.add("show-fb"); });
    if (allRight) { q.classList.add("solved"); verdict(q, T("correct"), true); }
    else if (multi) {
      var right = chosen.filter(function (o) { return o.getAttribute("data-correct") === "1"; }).length;
      var need = opts.filter(function (o) { return o.getAttribute("data-correct") === "1"; }).length;
      verdict(q, T("multiPartial", { r: right, n: need }) + (chosen.length > right ? T("plusWrong") : "") + T("tryAgain"), false);
    } else verdict(q, T("notQuite"), false);
  }

  function matchQuiz(q, act) {
    var rows = $$(".match-row", q);
    q.classList.remove("solved", "revealed");
    rows.forEach(function (r) { r.classList.remove("is-correct", "is-wrong"); $(".match-fb", r).textContent = ""; });
    if (act === "reset") { rows.forEach(function (r) { $("select", r).value = ""; }); verdict(q, ""); return; }
    if (act === "reveal") {
      rows.forEach(function (r) { $("select", r).value = r.getAttribute("data-answer"); r.classList.add("is-correct"); });
      q.classList.add("revealed"); verdict(q, T("pairsShown"), true); return;
    }
    var good = 0, empty = 0;
    rows.forEach(function (r) {
      var s = $("select", r), ok = s.value !== "" && s.value === r.getAttribute("data-answer");
      if (s.value === "") { empty++; return; }
      r.classList.add(ok ? "is-correct" : "is-wrong");
      if (!ok) $(".match-fb", r).textContent = T("notThis");
      if (ok) good++;
    });
    if (empty === rows.length) { verdict(q, T("matchFirst")); return; }
    if (good === rows.length) { q.classList.add("solved"); verdict(q, T("allPairs"), true); }
    else verdict(q, T("xOfY", { g: good, n: rows.length }) + (empty ? T("notAnswered", { e: empty }) : ""), false);
  }

  function blanksQuiz(q, act) {
    var rows = $$(".blank-row", q);
    q.classList.remove("solved", "revealed");
    rows.forEach(function (r) { r.classList.remove("is-correct", "is-wrong"); });
    if (act === "reset") { rows.forEach(function (r) { $("select", r).value = ""; }); verdict(q, ""); return; }
    if (act === "reveal") {
      rows.forEach(function (r) { $("select", r).value = r.getAttribute("data-answer"); r.classList.add("is-correct"); });
      q.classList.add("revealed"); verdict(q, T("filled"), true); return;
    }
    var good = 0, answered = 0;
    rows.forEach(function (r) {
      var s = $("select", r); if (s.value === "") return; answered++;
      var ok = s.value === r.getAttribute("data-answer");
      r.classList.add(ok ? "is-correct" : "is-wrong"); if (ok) good++;
    });
    if (!answered) { verdict(q, T("chooseFirst")); return; }
    if (good === rows.length) { q.classList.add("solved"); verdict(q, T("allCorrect"), true); }
    else verdict(q, good + " of " + rows.length + " correct", false);
  }

  /* ---------------- keyboard ---------------- */
  document.addEventListener("keydown", function (e) {
    var tag = (e.target.tagName || "").toLowerCase();
    var typing = tag === "input" || tag === "textarea" || tag === "select" || e.target.isContentEditable;
    if (e.key === "/" && !typing) { e.preventDefault(); var s = $("#search-input"); if (s) s.focus(); return; }
    if (e.key === "Escape") { document.body.classList.remove("nav-open"); var lb = $(".lightbox"); if (lb) lb.remove(); }
    if (typing || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if (e.key === "ArrowLeft") { var p = $('[data-nav="prev"]'); if (p) location.href = p.href; }
    if (e.key === "ArrowRight") { var n = $('[data-nav="next"]'); if (n) location.href = n.href; }
  });

  /* ---------------- print: open all collapsibles ---------------- */
  window.addEventListener("beforeprint", function () { $$("details").forEach(function (d) { d.setAttribute("data-was", d.open ? "1" : "0"); d.open = true; }); });
  window.addEventListener("afterprint", function () { $$("details[data-was]").forEach(function (d) { d.open = d.getAttribute("data-was") === "1"; }); });

  /* ---------------- search ---------------- */
  var input = $("#search-input"), box = $("#search-results");
  if (!input) return;
  var loading = false, sel = -1;

  function ensureIndex(cb) {
    if (window.SEARCH_INDEX) return cb();
    if (loading) return;
    loading = true;
    var s = document.createElement("script");
    s.src = ROOT + "assets/search-index.js";
    s.onload = function () { loading = false; cb(); };
    s.onerror = function () { loading = false; box.innerHTML = '<div class="sr-empty">' + T("noIndex") + '</div>'; box.hidden = false; };
    document.head.appendChild(s);
  }
  function escHtml(s) { return s.replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
  function mark(text, terms) {
    var out = escHtml(text);
    terms.forEach(function (t) { out = out.replace(new RegExp("(" + escRe(escHtml(t)) + ")", "gi"), "<mark>$1</mark>"); });
    return out;
  }

  function runSearch() {
    var qv = input.value.trim().toLowerCase();
    if (qv.length < 2) { box.hidden = true; box.innerHTML = ""; return; }
    var terms = qv.split(/\s+/).filter(Boolean);
    var results = [];
    window.SEARCH_INDEX.forEach(function (d) {
      var title = d.t.toLowerCase(), text = d.x.toLowerCase(), score = 0;
      for (var i = 0; i < terms.length; i++) {
        var t = terms[i], inTitle = title.indexOf(t) >= 0, pos = text.indexOf(t);
        if (!inTitle && pos < 0) return;
        if (inTitle) score += 20;
        if (pos >= 0) { var c = 0, p = pos; while (p >= 0 && c < 30) { c++; p = text.indexOf(t, p + t.length); } score += c; }
      }
      if (text.indexOf(qv) >= 0) score += 10;
      var head = null;
      for (var j = 0; j < d.h.length; j++) { if (terms.every(function (t) { return d.h[j][1].toLowerCase().indexOf(t) >= 0; })) { head = d.h[j]; score += 8; break; } }
      var at = text.indexOf(qv); if (at < 0) at = text.indexOf(terms[0]);
      var snip = "";
      if (at >= 0) { var s = Math.max(0, at - 70); snip = (s > 0 ? "…" : "") + d.x.substr(s, 200) + "…"; }
      results.push({ d: d, score: score, snip: snip, head: head });
    });
    results.sort(function (a, b) { return b.score - a.score; });
    results = results.slice(0, 12);
    sel = -1;
    if (!results.length) { box.innerHTML = '<div class="sr-empty">' + T("noMatch", { q: escHtml(input.value.trim()) }) + '</div>'; box.hidden = false; return; }
    box.innerHTML = results.map(function (r) {
      var url = ROOT + r.d.u + (r.head ? "#" + r.head[0] : "");
      return '<a class="sr-item" href="' + url + '"><div class="sr-title">' + mark(r.d.t, terms) + "</div>" +
        '<div class="sr-course">' + escHtml(r.d.c) + (r.head ? " › " + mark(r.head[1], terms) : "") + "</div>" +
        (r.snip ? '<div class="sr-snip">' + mark(r.snip, terms) + "</div>" : "") + "</a>";
    }).join("");
    box.hidden = false;
  }

  var timer;
  input.addEventListener("focus", function () { ensureIndex(function () { if (input.value.trim()) runSearch(); }); });
  input.addEventListener("input", function () { clearTimeout(timer); timer = setTimeout(function () { ensureIndex(runSearch); }, 90); });
  input.addEventListener("keydown", function (e) {
    var items = $$(".sr-item", box);
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      if (!items.length) return; e.preventDefault();
      sel = (sel + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length;
      items.forEach(function (it, i) { it.classList.toggle("sel", i === sel); });
      items[sel].scrollIntoView({ block: "nearest" });
    } else if (e.key === "Enter") {
      var target = items[sel >= 0 ? sel : 0]; if (target) location.href = target.href;
    } else if (e.key === "Escape") { box.hidden = true; input.blur(); }
  });
  document.addEventListener("click", function (e) { if (!e.target.closest(".search")) box.hidden = true; });
})();
