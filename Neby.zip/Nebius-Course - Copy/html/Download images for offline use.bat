@echo off
title Download course images for offline reading
echo Downloading course images into the html\assets\img folder...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0assets\download-images.ps1"
echo.
pause
