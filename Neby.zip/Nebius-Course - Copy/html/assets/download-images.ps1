# Downloads all course images into assets\img so the site can be read offline.
# Started by "Download images for offline use.bat". Safe to run again: existing files are skipped.
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
try { [Net.WebRequest]::DefaultWebProxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials } catch { }

$dest = Join-Path $PSScriptRoot 'img'
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$images = @(
    @{ Name = '1._Introduction_1793254866.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/1._Introduction_1793254866.jpg' }
    @{ Name = 'Host_process_and_MCP_servers_1793255242.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/Host_process_and_MCP_servers_1793255242.jpg' }
    @{ Name = 'Module_Overview__Building_your_Own_AI_Agent_v2_1792562864.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/Module_Overview__Building_your_Own_AI_Agent_v2_1792562864.png' }
    @{ Name = 'Roots_and_launch_command_1793268676.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/Roots_and_launch_command_1793268676.jpg' }
    @{ Name = 'Server_selection_flowchart_1793256835.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/Server_selection_flowchart_1793256835.jpg' }
    @{ Name = 'Three_message_patterns_1793270742.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/Three_message_patterns_1793270742.jpg' }
    @{ Name = 'What_is_MCP__1793255122.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/What_is_MCP__1793255122.jpg' }
    @{ Name = 'diagram_1778768892.jpg'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/diagram_1778768892.jpg' }
    @{ Name = 'image_10_1793264930.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_10_1793264930.png' }
    @{ Name = 'image_11_1793269898.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_11_1793269898.png' }
    @{ Name = 'image_12_1793269908.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_12_1793269908.png' }
    @{ Name = 'image_13_1793269952.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_13_1793269952.png' }
    @{ Name = 'image_14_1793269962.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_14_1793269962.png' }
    @{ Name = 'image_15_1793269973.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_15_1793269973.png' }
    @{ Name = 'image_16_1793269990.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_16_1793269990.png' }
    @{ Name = 'image_1777559265.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1777559265.png' }
    @{ Name = 'image_1779773726.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1779773726.png' }
    @{ Name = 'image_1793264444.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1793264444.png' }
    @{ Name = 'image_1793338916.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1793338916.png' }
    @{ Name = 'image_17_1793270001.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_17_1793270001.png' }
    @{ Name = 'image_18_1793270089.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_18_1793270089.png' }
    @{ Name = 'image_1_1779889906.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1_1779889906.png' }
    @{ Name = 'image_1_1793264599.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1_1793264599.png' }
    @{ Name = 'image_1_1793339043.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_1_1793339043.png' }
    @{ Name = 'image_2_1778757909.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_2_1778757909.png' }
    @{ Name = 'image_2_1779891002.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_2_1779891002.png' }
    @{ Name = 'image_2_1793264610.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_2_1793264610.png' }
    @{ Name = 'image_2_1793339117.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_2_1793339117.png' }
    @{ Name = 'image_3_1778757947.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_3_1778757947.png' }
    @{ Name = 'image_3_1792562980.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_3_1792562980.png' }
    @{ Name = 'image_3_1793264682.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_3_1793264682.png' }
    @{ Name = 'image_3_1793339132.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_3_1793339132.png' }
    @{ Name = 'image_4_1778757988.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_4_1778757988.png' }
    @{ Name = 'image_4_1792562996.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_4_1792562996.png' }
    @{ Name = 'image_4_1793264742.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_4_1793264742.png' }
    @{ Name = 'image_4_1793339188.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_4_1793339188.png' }
    @{ Name = 'image_5_1778758033.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_5_1778758033.png' }
    @{ Name = 'image_5_1792572375.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_5_1792572375.png' }
    @{ Name = 'image_5_1793264752.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_5_1793264752.png' }
    @{ Name = 'image_5_1793339244.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_5_1793339244.png' }
    @{ Name = 'image_6_1778758068.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_6_1778758068.png' }
    @{ Name = 'image_6_1793264856.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_6_1793264856.png' }
    @{ Name = 'image_6_1793339321.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_6_1793339321.png' }
    @{ Name = 'image_7_1778762793.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_7_1778762793.png' }
    @{ Name = 'image_7_1793264865.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_7_1793264865.png' }
    @{ Name = 'image_8_1793264878.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_8_1793264878.png' }
    @{ Name = 'image_9_1793264916.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/image_9_1793264916.png' }
    @{ Name = 'screenshot-1791487533618_1792566193.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791487533618_1792566193.png' }
    @{ Name = 'screenshot-1791493966736_1792572872.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791493966736_1792572872.png' }
    @{ Name = 'screenshot-1791494144889_1792573277.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791494144889_1792573277.png' }
    @{ Name = 'screenshot-1791494783357_1792574072.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791494783357_1792574072.png' }
    @{ Name = 'screenshot-1791495401994_1792574535.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791495401994_1792574535.png' }
    @{ Name = 'screenshot-1791495431018_1792574555.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791495431018_1792574555.png' }
    @{ Name = 'screenshot-1791495492964_1792574566.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791495492964_1792574566.png' }
    @{ Name = 'screenshot-1791495536183_1792574654.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791495536183_1792574654.png' }
    @{ Name = 'screenshot-1791495603918_1792574626.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791495603918_1792574626.png' }
    @{ Name = 'screenshot-1791497412052_1792575723.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791497412052_1792575723.png' }
    @{ Name = 'screenshot-1791497444348_1792575737.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791497444348_1792575737.png' }
    @{ Name = 'screenshot-1791497463249_1792575753.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791497463249_1792575753.png' }
    @{ Name = 'screenshot-1791497490932_1792575766.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791497490932_1792575766.png' }
    @{ Name = 'screenshot-1791497554525_1792575793.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791497554525_1792575793.png' }
    @{ Name = 'screenshot-1791498218695_1792576335.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498218695_1792576335.png' }
    @{ Name = 'screenshot-1791498244104_1792576358.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498244104_1792576358.png' }
    @{ Name = 'screenshot-1791498262463_1792576371.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498262463_1792576371.png' }
    @{ Name = 'screenshot-1791498304140_1792576380.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498304140_1792576380.png' }
    @{ Name = 'screenshot-1791498355044_1792576423.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498355044_1792576423.png' }
    @{ Name = 'screenshot-1791498946840_1792577311.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498946840_1792577311.png' }
    @{ Name = 'screenshot-1791498971417_1792577364.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791498971417_1792577364.png' }
    @{ Name = 'screenshot-1791499013301_1792577375.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791499013301_1792577375.png' }
    @{ Name = 'screenshot-1791499683044_1792578007.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791499683044_1792578007.png' }
    @{ Name = 'screenshot-1791499711644_1792578019.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791499711644_1792578019.png' }
    @{ Name = 'screenshot-1791501950088_1792566445.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791501950088_1792566445.png' }
    @{ Name = 'screenshot-1791513241511_1792576395.png'; Url = 'https://practicum-content.s3.us-west-1.amazonaws.com/resources/screenshot-1791513241511_1792576395.png' }
)

$ok = 0; $skipped = 0; $failed = @(); $i = 0
foreach ($img in $images) {
    $i++
    $file = Join-Path $dest $img.Name
    if ((Test-Path -LiteralPath $file) -and ((Get-Item -LiteralPath $file).Length -gt 0)) { $skipped++; continue }
    Write-Host ("[{0,2}/{1}] {2}" -f $i, $images.Count, $img.Name)
    $tmp = $file + '.part'
    try {
        $wc = New-Object System.Net.WebClient
        $wc.DownloadFile($img.Url, $tmp)
        Move-Item -LiteralPath $tmp -Destination $file -Force
        $ok++
    } catch {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
        $failed += $img.Name
        Write-Host ("        failed: " + $_.Exception.Message) -ForegroundColor Red
    }
}

Write-Host ''
Write-Host ("Done. Downloaded: {0}   Already there: {1}   Failed: {2}" -f $ok, $skipped, $failed.Count) -ForegroundColor Cyan
if ($failed.Count -gt 0) {
    Write-Host 'Some images failed. Check your internet connection and run the downloader again.' -ForegroundColor Yellow
    exit 1
}
Write-Host 'All images are saved. The course pages now work without internet.' -ForegroundColor Green
