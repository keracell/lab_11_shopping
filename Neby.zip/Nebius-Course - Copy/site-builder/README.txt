Rebuild the course site (English + Russian) from neb.json
=========================================================
1. pip install markdown-it-py pygments
2. From the Nebius-Course folder run:
       python site-builder/build_course.py
   It reads neb.json and writes html\ (English) and html-ru\ (Russian).

Russian translations live in site-builder\translations\ru\lessons\ (one file per lesson, e.g. mcp-02.txt).
Lessons without a translation appear in English on the Russian site, with a notice.
The build also regenerates translations\ru\source\ (the English text to translate) and
i18n_check.py <lesson-key> checks a translation file against it.
Design: site-builder\static\style.css and app.js (copied into both sites on each build).
