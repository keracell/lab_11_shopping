#!/usr/bin/env python3
"""
Build a browsable static HTML site (English + Russian) from a Nebius Academy course export (neb.json).

Usage (from the Nebius-Course folder):
    pip install markdown-it-py pygments
    python site-builder/build_course.py
    python site-builder/build_course.py <neb.json> <html-dir> <html-ru-dir>     (explicit paths)

Output:
    html/                     English site (index.html, assets/, one folder per course)
    html-ru/                  Russian site with the same folder and file names; RU/EN switch in the top bar
Translations:
    site-builder/translations/ru/source/<key>.txt    text to translate, one file per lesson (regenerated on build)
    site-builder/translations/ru/lessons/<key>*.txt  Russian text for the same "@@@ <id>" blocks
    Lessons without a translation are shown in English on the Russian site, with a notice.
"""
import hashlib
import html
import json
import os
import re
import shutil
import sys
import textwrap
import urllib.parse
from collections import deque
from pathlib import Path

from markdown_it import MarkdownIt
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_by_name
from pygments.util import ClassNotFound

HERE = Path(__file__).resolve().parent
TRANSLATIONS = HERE / "translations"
COURSE_KEYS = ["agent", "mcp", "multi"]   # lesson keys: agent-01, mcp-02, multi-12 …
IMAGES = {}                               # original image URL -> local file name (shared by both languages)

esc = lambda s: html.escape(str(s if s is not None else ""), quote=True)

# --------------------------------------------------------------------------------------
# Interface strings
# --------------------------------------------------------------------------------------
UI = {
    "en": {
        "site_title": "Nebius Academy Courses", "all_courses": "All courses", "course_overview": "Course overview",
        "courses": "Courses", "search_ph": "Search all lessons…  ( / )", "search_aria": "Search all lessons",
        "width_title": "Content width", "width_wide": "Wide", "theme_title": "Light / dark", "toggle_nav": "Toggle navigation",
        "on_this_page": "On this page", "lesson_x_of_y": "Lesson {n} of {total}", "lesson_n": "Lesson {n}",
        "min_read": "~{n} min read", "min": "{n} min", "repo": "Repo", "completed": "Completed", "you_are_here": "You are here",
        "show_all_answers": "Show all answers", "prev": "← Previous", "next": "Next →",
        "course_x_of_y": "Course {n} of {total}", "theory_n": "{n} theory", "practice_n": "{n} practice",
        "hours_reading": "~{h} h reading", "hours": "~{h} h", "progress_text": "{done}/{total} completed",
        "progress_title": "{done} of {total} lessons completed", "cta_continue": "Continue", "cta_start": "Start course",
        "cta_review": "Review from the start", "open_course": "Open course", "continue_to": "Continue: {name} →",
        "all_lessons_title": "All lessons",
        "home_lead": "{courses} · {lessons} · {quizzes}. Use the search box (press <kbd>/</kbd>) to find any topic across every lesson.",
        "checking_offline": "Checking offline images…",
        "Theory": "Theory", "Practice": "Practice", "Project": "Project",
        "quiz": "Quiz", "match": "Match the pairs", "blanks": "Fill in the blanks", "your_answer": "Your answer",
        "ai_task": "Task · reviewed by AI on the platform", "select_all": "Select all that apply", "choose": "Choose…",
        "check": "Check", "show_answer": "Show answer", "reset": "Reset", "submit": "Submit",
        "text_ph": "Write your answer here (kept only in this browser tab)",
        "ai_ph": "Draft your answer here, then compare it with the examples below",
        "good_examples": "Examples of strong answers", "bad_examples": "Examples of weak answers", "rubric": "Reviewer rubric",
        "copy": "Copy", "copy_aria": "Copy code", "more": "More", "checklist": "Checklist",
        "img_missing": "Image not available: run Download images for offline use.bat while online",
        "lang_title": "Читать на русском", "not_translated": "", "partly_translated": "", "untranslated_tag": "",
        "plural": {"course": ("course", "courses"), "lesson": ("lesson", "lessons"), "quiz": ("quiz", "quizzes")},
    },
    "ru": {
        "site_title": "Курсы Nebius Academy", "all_courses": "Все курсы", "course_overview": "Обзор курса",
        "courses": "Курсы", "search_ph": "Поиск по всем урокам…  ( / )", "search_aria": "Поиск по всем урокам",
        "width_title": "Ширина текста", "width_wide": "Широко", "theme_title": "Светлая / тёмная тема", "toggle_nav": "Показать навигацию",
        "on_this_page": "На этой странице", "lesson_x_of_y": "Урок {n} из {total}", "lesson_n": "Урок {n}",
        "min_read": "~{n} мин чтения", "min": "{n} мин", "repo": "Репозиторий", "completed": "Пройден", "you_are_here": "Вы здесь",
        "show_all_answers": "Показать все ответы", "prev": "← Назад", "next": "Далее →",
        "course_x_of_y": "Курс {n} из {total}", "theory_n": "теория: {n}", "practice_n": "практика: {n}",
        "hours_reading": "~{h} ч чтения", "hours": "~{h} ч", "progress_text": "пройдено {done}/{total}",
        "progress_title": "Пройдено уроков: {done} из {total}", "cta_continue": "Продолжить", "cta_start": "Начать курс",
        "cta_review": "Повторить с начала", "open_course": "Открыть курс", "continue_to": "Продолжить: {name} →",
        "all_lessons_title": "Все уроки",
        "home_lead": "{courses} · {lessons} · {quizzes}. Чтобы найти любую тему во всех уроках, воспользуйтесь поиском (клавиша <kbd>/</kbd>).",
        "checking_offline": "Проверяем изображения для чтения без интернета…",
        "Theory": "Теория", "Practice": "Практика", "Project": "Проект",
        "quiz": "Тест", "match": "Сопоставьте пары", "blanks": "Заполните пропуски", "your_answer": "Ваш ответ",
        "ai_task": "Задание · на платформе проверяется ИИ", "select_all": "Выберите все подходящие варианты", "choose": "Выберите…",
        "check": "Проверить", "show_answer": "Показать ответ", "reset": "Сбросить", "submit": "Отправить",
        "text_ph": "Напишите ответ здесь (он хранится только в этой вкладке браузера)",
        "ai_ph": "Набросайте ответ здесь, а затем сравните его с примерами ниже",
        "good_examples": "Примеры сильных ответов", "bad_examples": "Примеры слабых ответов", "rubric": "Критерии проверки",
        "copy": "Копировать", "copy_aria": "Копировать код", "more": "Подробнее", "checklist": "Чек-лист",
        "img_missing": "Изображение недоступно: запустите Download images for offline use.bat в папке html, пока есть интернет",
        "lang_title": "Read in English",
        "not_translated": "Этот урок ещё не переведён — текст показан на английском.",
        "partly_translated": "Перевод этого урока не завершён — часть текста показана на английском.",
        "untranslated_tag": "Ещё не переведено",
        "plural": {"course": ("курс", "курса", "курсов"), "lesson": ("урок", "урока", "уроков"), "quiz": ("тест", "теста", "тестов")},
    },
}


class Ctx:
    """State of the site currently being built."""
    lang = "en"
    translator = None      # Translator for non-English sites
    collector = None       # Collector while building the English site
    page = None            # per-lesson state while rendering a lesson body
    img_prefix = "../assets/img/"


def ui(key, **kw):
    s = UI[Ctx.lang][key]
    return s.format(**kw) if kw else s


def count(n, word):
    forms = UI[Ctx.lang]["plural"][word]
    if Ctx.lang == "ru":
        m, m10 = abs(n) % 100, abs(n) % 10
        form = forms[2] if 10 < m < 20 else forms[0] if m10 == 1 else forms[1] if 2 <= m10 <= 4 else forms[2]
    else:
        form = forms[0] if n == 1 else forms[1]
    return f"{n} {form}"


def num(x):
    s = f"{x}"
    return s.replace(".", ",") if Ctx.lang == "ru" else s


# --------------------------------------------------------------------------------------
# Translation units
# --------------------------------------------------------------------------------------
FENCE_RE = re.compile(r"^([ \t]*)(`{3,}|~{3,})[^\n]*\n.*?^\1\2[ \t]*$", re.S | re.M)
IMG_MD_RE = re.compile(r"!\[[^\]\n]*\]\([^)\s]*(?:\s+\"[^\"]*\")?\)")
URL_MD_RE = re.compile(r"\]\((https?://[^)\s]+)\)")
SLOT_RE = re.compile(r"⟦[CIU](\d+)⟧")
UNIT_SPLIT = re.compile(r"^@@@ ([0-9a-f]{10})[ \t]*$", re.M)


def mask(text):
    """Hide code blocks, images and link targets behind ⟦C1⟧ / ⟦I2⟧ / ⟦U3⟧ so only prose is translated."""
    slots = []

    def put(kind, value):
        slots.append(value)
        return f"⟦{kind}{len(slots)}⟧"

    text = FENCE_RE.sub(lambda m: m.group(1) + put("C", m.group(0)[len(m.group(1)):]), text)
    text = IMG_MD_RE.sub(lambda m: put("I", m.group(0)), text)
    text = URL_MD_RE.sub(lambda m: "](" + put("U", m.group(1)) + ")", text)
    return text, slots


def unmask(text, slots):
    def back(m):
        i = int(m.group(1))
        return slots[i - 1] if 1 <= i <= len(slots) else m.group(0)
    return SLOT_RE.sub(back, text)


def unit_id(masked: str) -> str:
    return hashlib.sha1(masked.encode("utf-8")).hexdigest()[:10]


def parse_units(text: str) -> dict:
    parts = UNIT_SPLIT.split(text.replace("\r\n", "\n"))
    return {parts[i]: parts[i + 1].strip("\n").strip() for i in range(1, len(parts), 2)}


class Translator:
    def __init__(self, lang):
        self.map, self.keys = {}, set()
        folder = TRANSLATIONS / lang / "lessons"
        if folder.exists():
            for f in sorted(folder.glob("*.txt")):
                self.keys.add(f.name.split(".")[0])
                self.map.update({k: v for k, v in parse_units(f.read_text(encoding="utf-8")).items() if v})


class Collector:
    def __init__(self):
        self.units, self.titles = {}, {}

    def add(self, key, uid, masked):
        self.units.setdefault(key, {}).setdefault(uid, masked)

    def write(self, lang):
        src = TRANSLATIONS / lang / "source"
        src.mkdir(parents=True, exist_ok=True)
        for key, units in self.units.items():
            meta = self.titles.get(key, "")
            body = "".join(f"@@@ {uid}\n{masked}\n\n" for uid, masked in units.items())
            for masked in units.values():
                assert not UNIT_SPLIT.search(masked), "unit text must not contain an @@@ line"
            (src / f"{key}.txt").write_text(
                f"Source text for {key}{(': ' + meta) if meta else ''}\n"
                f"Translate every block below. Keep each '@@@ <id>' line unchanged and in the same order.\n\n" + body,
                encoding="utf-8", newline="\n")


def tx(text):
    """Translate a piece of course text into the language of the site being built (identity for English)."""
    if not text or not text.strip():
        return text or ""
    core = text.strip()
    masked, slots = mask(core)
    uid = unit_id(masked)
    page = Ctx.page
    if Ctx.collector is not None:
        Ctx.collector.add(page["key"] if page else "_titles", uid, masked)
    if Ctx.lang == "en" or Ctx.translator is None:
        return text
    if page:
        page["units"] += 1
    tr = Ctx.translator.map.get(uid)
    if not tr:
        if page:
            page["missing"] += 1
        return text
    lead, trail = text[:len(text) - len(text.lstrip())], text[len(text.rstrip()):]
    return lead + unmask(tr, slots) + trail


# --------------------------------------------------------------------------------------
# Markdown rendering
# --------------------------------------------------------------------------------------
LANG_ALIASES = {"sh": "bash", "shell": "bash", "zsh": "bash", "console": "bash",
                "py": "python", "yml": "yaml", "md": "markdown", "js": "javascript",
                "ts": "typescript", "jsonc": "json"}
CODE_FMT = HtmlFormatter(nowrap=True)


def code_block_html(code: str, lang: str) -> str:
    lang = (lang or "").strip().lower()
    lexer = None
    if lang and lang not in ("text", "plain", "plaintext", "mermaid"):
        try:
            lexer = get_lexer_by_name(LANG_ALIASES.get(lang, lang))
        except ClassNotFound:
            lexer = None
    body = highlight(code, lexer, CODE_FMT) if lexer else esc(code)
    label = esc(lang) if lang else ""
    return (f'<div class="code"><div class="code-head"><span class="code-lang">{label}</span>'
            f'<button class="copy-btn" type="button" aria-label="{esc(ui("copy_aria"))}">{esc(ui("copy"))}</button></div>'
            f'<pre><code>{body.rstrip()}</code></pre></div>\n')


def slugify(text: str) -> str:
    s = re.sub(r"<[^>]+>", "", text)
    s = html.unescape(s).lower()
    s = re.sub(r"[^\w\s-]", "", s, flags=re.UNICODE)
    s = re.sub(r"[\s_]+", "-", s).strip("-")
    return s[:60] or "section"


def img_onerror():
    return ("if(!this.dataset.tried){this.dataset.tried=1;this.src=this.dataset.remote}"
            "else{this.onerror=null;this.classList.add('broken');this.alt=" + json.dumps(ui("img_missing")).replace('"', "'") + "}")


def build_md() -> MarkdownIt:
    md = MarkdownIt("commonmark", {"html": False, "linkify": False, "typographer": False})
    md.enable(["table", "strikethrough"])
    md.disable("code")  # the platform has no indented code blocks; indented lines in callouts are plain text

    def r_fence(self, tokens, idx, options, env):
        t = tokens[idx]
        lang = t.info.strip().split()[0] if t.info.strip() else ""
        return code_block_html(t.content, lang)

    def r_link_open(self, tokens, idx, options, env):
        t = tokens[idx]
        if re.match(r"https?://", t.attrGet("href") or ""):
            t.attrSet("target", "_blank")
            t.attrSet("rel", "noopener noreferrer")
            t.attrJoin("class", "ext")
        return self.renderToken(tokens, idx, options, env)

    def r_image(self, tokens, idx, options, env):
        t = tokens[idx]
        src = t.attrGet("src") or ""
        alt = self.renderInlineAsText(t.children or [], options, env)
        title = t.attrGet("title") or ""
        extra = f' title="{esc(title)}"' if title else ""
        if re.match(r"https?://", src):
            # Use the downloaded copy in html/assets/img if present, otherwise fall back to the online original.
            local = Ctx.img_prefix + local_image_name(src)
            return (f'<img class="md-img" src="{esc(local)}" data-remote="{esc(src)}" alt="{esc(alt)}" loading="lazy"{extra} '
                    f'onerror="{esc(img_onerror())}">')
        return f'<img class="md-img" src="{esc(src)}" alt="{esc(alt)}" loading="lazy"{extra}>'

    md.add_render_rule("fence", r_fence)
    md.add_render_rule("link_open", r_link_open)
    md.add_render_rule("image", r_image)
    md.add_render_rule("table_open", lambda self, tokens, idx, options, env: '<div class="table-wrap"><table>\n')
    md.add_render_rule("table_close", lambda self, tokens, idx, options, env: "</table></div>\n")
    return md


def local_image_name(url: str) -> str:
    if url in IMAGES:
        return IMAGES[url]
    base = urllib.parse.unquote(urllib.parse.urlparse(url).path.rsplit("/", 1)[-1]) or "image"
    base = re.sub(r"[^\w.\-]", "_", base, flags=re.ASCII)[:120]
    name, n = base, 2
    while name in IMAGES.values():
        stem, dot, ext = base.rpartition(".")
        name = f"{stem or base}-{n}{dot}{ext if stem else ''}"
        n += 1
    IMAGES[url] = name
    return name


MD = build_md()
CALLOUT_RE = re.compile(r"\{quiz-task\}\n(.*?)\n?\{/quiz-task\}", re.S)
CALLOUT_BODY_RE = re.compile(r"\s*preset:\s*\|?\s*\n\s*(\w+)[^\n]*\n\s*content:\s*\|?\s*\n(.*)", re.S)


def normalize(text: str) -> str:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    return text.replace('{target="_blank"}', "")


def render_md(text: str, page, toc: bool = False) -> str:
    """Render markdown; headings get ids (the Russian site reuses the English ids), h2/h3 go to the page TOC."""
    tokens = MD.parse(text, {})
    for i, t in enumerate(tokens):
        if t.type == "heading_open":
            inline = tokens[i + 1]
            plain = re.sub(r"\s+", " ", "".join(c.content for c in (inline.children or []) if c.type in ("text", "code_inline"))).strip()
            forced = page.get("forced")
            base = forced.popleft() if forced else slugify(plain)
            slug, n = base, 2
            while slug in page["slugs"]:
                slug, n = f"{base}-{n}", n + 1
            page["slugs"].add(slug)
            page["slug_order"].append(slug)
            t.attrSet("id", slug)
            if toc and t.tag in ("h2", "h3"):
                page["toc"].append((t.tag, slug, plain))
    return MD.renderer.render(tokens, MD.options, {})


def render_markdown_block(text: str, page, toc: bool = False) -> str:
    """Markdown with the platform's {quiz-task} callout syntax split out; each piece is translated separately."""
    text = normalize(text)
    out, pos = [], 0
    for m in CALLOUT_RE.finditer(text):
        out.append(render_md(tx(text[pos:m.start()]), page, toc))
        bm = CALLOUT_BODY_RE.match(m.group(1))
        preset, body = (bm.group(1).lower(), textwrap.dedent(bm.group(2))) if bm else ("default", m.group(1))
        page["stats"]["callout"] += 1
        out.append(f'<div class="callout callout-{esc(preset)}">{render_md(tx(body), page)}</div>\n')
        pos = m.end()
    out.append(render_md(tx(text[pos:]), page, toc))
    return "".join(out)


def md_inline(text: str) -> str:
    return MD.renderInline(tx(normalize(text)).strip())


def plain(text: str) -> str:
    return tx(normalize(text)).strip()


# --------------------------------------------------------------------------------------
# Block renderers (one per node type in the lesson tree)
# --------------------------------------------------------------------------------------
def render_node(node, page, depth=0) -> str:
    t, c = node.get("type"), node.get("content") or {}
    page["stats"][t] = page["stats"].get(t, 0) + 1
    kids = node.get("nested") or []
    inner = lambda: "".join(render_node(k, page, depth + 1) for k in kids)

    if t == "RootLayout":
        return inner()

    if t == "Markdown":
        return f'<div class="md" data-b="Markdown">{render_markdown_block(c.get("markdown", ""), page, toc=(depth <= 1))}</div>\n'

    if t == "CutContainer":
        title = md_inline(c["title"]) if c.get("title") else esc(ui("more"))
        return (f'<details class="cut" data-b="CutContainer"><summary><span class="cut-title">{title}</span></summary>'
                f'<div class="cut-body">{inner()}</div></details>\n')

    if t == "ActionButton":
        txt = plain(c.get("text") or "")
        return f'<div class="step-divider" data-b="ActionButton"><span>{esc(txt)}</span></div>\n' if txt else '<div class="step-divider" data-b="ActionButton"></div>\n'

    if t == "Checklist":
        items = "".join(
            f'<li><label><input type="checkbox" data-key="{esc(o.get("id"))}"><span>{md_inline(o.get("content", ""))}</span></label></li>'
            for o in c.get("options") or [])
        title = md_inline(c["title"]) if c.get("title") else esc(ui("checklist"))
        extra = render_markdown_block(c["content"], page) if (c.get("content") or "").strip() else ""
        return (f'<div class="checklist" data-b="Checklist"><div class="checklist-title">{title}</div>'
                f'{extra}<ul>{items}</ul></div>\n')

    if t == "QuizSelect":
        page["quizzes"] += 1
        multi = c.get("type") == "checkbox"
        name = f'q-{c.get("id", node.get("id"))}'
        opts = []
        for o in c.get("options") or []:
            fb = (o.get("feedback") or "").strip()
            opts.append(
                f'<li class="opt" data-correct="{1 if o.get("correct") else 0}"><label>'
                f'<input type="{"checkbox" if multi else "radio"}" name="{esc(name)}">'
                f'<span class="opt-text">{md_inline(o.get("content", ""))}</span></label>'
                + (f'<div class="opt-fb">{md_inline(fb)}</div>' if fb else "") + "</li>")
        hint = f'<div class="quiz-hint">{esc(ui("select_all"))}</div>' if multi else ""
        return (f'<div class="quiz quiz-select" data-b="QuizSelect" data-multi="{int(multi)}" '
                f'data-showall="{int(bool(c.get("show_all_feedback")))}">'
                f'<div class="quiz-label">{esc(ui("quiz"))}</div>'
                f'<div class="quiz-q">{render_markdown_block(c.get("content", ""), page)}</div>{hint}'
                f'<ul class="opts">{"".join(opts)}</ul>{quiz_actions()}</div>\n')

    if t == "QuizMacaroni":
        page["quizzes"] += 1
        left = (c.get("options") or {}).get("left", {}).get("choices") or []
        right = (c.get("options") or {}).get("right", {}).get("choices") or []
        sets = c.get("correct_answers") or [[]]
        answer = {l: r for l, r in (sets[0] if sets else [])}
        sel_opts = f'<option value="">{esc(ui("choose"))}</option>' + "".join(
            f'<option value="{i}">{esc(re.sub(r"[*`]", "", plain(r)))}</option>' for i, r in enumerate(right))
        rows = "".join(
            f'<li class="match-row" data-answer="{answer.get(i, "")}"><div class="match-left">{md_inline(l)}</div>'
            f'<select aria-label="{esc(ui("match"))}">{sel_opts}</select><div class="match-fb"></div></li>'
            for i, l in enumerate(left))
        fb = (c.get("feedback") or "").strip()
        return (f'<div class="quiz quiz-match" data-b="QuizMacaroni"><div class="quiz-label">{esc(ui("match"))}</div>'
                f'<div class="quiz-q">{render_markdown_block(c.get("question", ""), page)}</div>'
                f'<ul class="match">{rows}</ul>'
                + (f'<div class="quiz-feedback">{render_markdown_block(fb, page)}</div>' if fb else "")
                + f'{quiz_actions()}</div>\n')

    if t == "QuizChoice":
        page["quizzes"] += 1
        options = c.get("options") or []
        sel_opts = f'<option value="">{esc(ui("choose"))}</option>' + "".join(
            f'<option value="{esc(o.get("id"))}">{esc(plain(o.get("content", "")))}</option>' for o in options)
        rows = []
        for q in c.get("questions") or []:
            pos, neg = (q.get("feedback-positive") or "").strip(), (q.get("feedback-negative") or "").strip()
            rows.append(
                f'<li class="blank-row" data-answer="{esc(q.get("correct_option"))}">'
                f'<div class="blank-q">{md_inline(q.get("content", ""))} <select aria-label="{esc(ui("choose"))}">{sel_opts}</select></div>'
                f'<div class="blank-fb pos">{md_inline(pos)}</div><div class="blank-fb neg">{md_inline(neg)}</div></li>')
        return (f'<div class="quiz quiz-blanks" data-b="QuizChoice"><div class="quiz-label">{esc(ui("blanks"))}</div>'
                f'<div class="quiz-q">{render_markdown_block(c.get("content", ""), page)}</div>'
                f'<ol class="blanks">{"".join(rows)}</ol>{quiz_actions()}</div>\n')

    if t == "QuizText":
        page["quizzes"] += 1
        result = (c.get("result_text") or "").strip()
        return (f'<div class="quiz quiz-text" data-b="QuizText"><div class="quiz-label">{esc(ui("your_answer"))}</div>'
                f'<div class="quiz-q">{render_markdown_block(c.get("content", ""), page)}</div>'
                f'<textarea rows="5" placeholder="{esc(ui("text_ph"))}"></textarea>'
                f'<div class="quiz-actions"><button type="button" class="btn btn-primary" data-act="submit-text">{esc(ui("submit"))}</button></div>'
                + (f'<div class="quiz-result">{md_inline(result)}</div>' if result else "") + "</div>\n")

    if t == "QuizAiFeedback":
        page["quizzes"] += 1
        parts = [f'<div class="quiz quiz-ai" data-b="QuizAiFeedback"><div class="quiz-label">{esc(ui("ai_task"))}</div>']
        desc = (c.get("description") or "").strip()
        if desc:
            parts.append(f'<div class="quiz-q">{render_markdown_block(desc, page)}</div>')
        parts.append(f'<textarea rows="6" placeholder="{esc(ui("ai_ph"))}"></textarea>')
        good = [x for x in c.get("correct_answer_examples") or [] if (x or "").strip()]
        bad = [x for x in c.get("incorrect_answer_examples") or [] if (x or "").strip()]
        if good:
            parts.append(f'<details class="cut cut-good"><summary><span class="cut-title">{esc(ui("good_examples"))}</span></summary><div class="cut-body">'
                         + "".join(render_markdown_block(x, page) for x in good) + "</div></details>")
        if bad:
            parts.append(f'<details class="cut cut-bad"><summary><span class="cut-title">{esc(ui("bad_examples"))}</span></summary><div class="cut-body">'
                         + "".join(render_markdown_block(x, page) for x in bad) + "</div></details>")
        if (c.get("custom_prompt") or "").strip():
            parts.append(f'<details class="cut"><summary><span class="cut-title">{esc(ui("rubric"))}</span></summary><div class="cut-body">'
                         + render_markdown_block(c["custom_prompt"], page) + "</div></details>")
        parts.append("</div>\n")
        return "".join(parts)

    if t == "QuizFeedback":
        # Platform satisfaction survey ("how useful was this module?") – not course content.
        return '<!-- course feedback survey omitted -->\n'

    page["stats"]["unknown:" + str(t)] = page["stats"].get("unknown:" + str(t), 0) + 1
    return f'<div class="unknown-block" data-b="{esc(t)}">{inner()}</div>\n'


def quiz_actions() -> str:
    return ('<div class="quiz-actions">'
            f'<button type="button" class="btn btn-primary" data-act="check">{esc(ui("check"))}</button>'
            f'<button type="button" class="btn" data-act="reveal">{esc(ui("show_answer"))}</button>'
            f'<button type="button" class="btn btn-ghost" data-act="reset">{esc(ui("reset"))}</button>'
            '<span class="quiz-verdict" aria-live="polite"></span></div>')


# --------------------------------------------------------------------------------------
# Page chrome
# --------------------------------------------------------------------------------------
def safe_filename(name: str, maxlen: int = 80) -> str:
    s = re.sub(r'[\\/:*?"<>|]', "", name)
    s = re.sub(r"\s+", " ", s).strip().rstrip(".")
    if len(s) > maxlen:  # drop parenthetical asides first, then cut at a word boundary
        s = re.sub(r"\s*\([^)]*\)", "", s).strip()
    if len(s) > maxlen:
        s = s[:maxlen].rsplit(" ", 1)[0]
    return s.rstrip(" .,;:-")


def href(*parts) -> str:
    return "/".join(urllib.parse.quote(p) for p in parts)


ICONS = {
    "check": '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    "menu": '<svg viewBox="0 0 20 20" width="20" height="20" aria-hidden="true"><path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    "search": '<svg viewBox="0 0 20 20" width="16" height="16" aria-hidden="true"><circle cx="9" cy="9" r="6" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M13.5 13.5L18 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    "theme": '<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true"><circle cx="10" cy="10" r="7" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M10 3a7 7 0 010 14z" fill="currentColor"/></svg>',
    "width": '<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true"><path d="M2 10h16M5 7l-3 3 3 3M15 7l3 3-3 3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
}


def kind_badge(lesson) -> str:
    k = lesson["kind"]
    return f'<span class="badge badge-{k.lower()}">{esc(ui(k))}</span>'


def status_mark(lesson) -> str:
    if lesson["passed"]:
        return f'<span class="st st-done" title="{esc(ui("completed"))}">{ICONS["check"]}</span>'
    if lesson["current"]:
        return f'<span class="st st-current" title="{esc(ui("you_are_here"))}"></span>'
    return '<span class="st st-todo"></span>'


def en_tag(lesson) -> str:
    if Ctx.lang != "en" and lesson.get("coverage", 1) < 1:
        return f'<span class="tag-en" title="{esc(ui("untranslated_tag"))}">EN</span>'
    return ""


def sidebar(courses, root: str, active_course=None, active_lesson=None) -> str:
    out = ['<nav class="sidebar" id="sidebar" aria-label="Course navigation"><div class="sidebar-inner">',
           f'<a class="side-home{" active" if active_course is None else ""}" href="{root}index.html">{esc(ui("all_courses"))}</a>']
    for co in courses:
        is_open = co is active_course
        done = sum(l["passed"] for l in co["lessons"])
        out.append(f'<details class="side-course"{" open" if is_open else ""}><summary>'
                   f'<span class="side-course-name">{esc(co["title"])}</span>'
                   f'<span class="side-course-meta">{done}/{len(co["lessons"])}</span></summary>')
        out.append(f'<a class="side-overview{" active" if is_open and active_lesson is None else ""}" href="{root}{href(co["dir"], "index.html")}">{esc(ui("course_overview"))}</a><ol class="side-lessons">')
        for l in co["lessons"]:
            act = " active" if l is active_lesson else ""
            out.append(f'<li><a class="side-lesson{act}" href="{root}{href(co["dir"], l["file"])}"'
                       + (' aria-current="page"' if act else "") + f'>{status_mark(l)}'
                       f'<span class="side-num">{l["num"]}</span><span class="side-title">{esc(l["title"])}</span>{en_tag(l)}</a></li>')
        out.append("</ol></details>")
    out.append("</div></nav>")
    return "".join(out)


def lang_switch(root: str, page_path: str) -> str:
    other = Ctx.other_rel
    items = []
    for code in ("en", "ru"):
        label = code.upper()
        if code == Ctx.lang:
            items.append(f'<span class="active" aria-current="true">{label}</span>')
        else:
            items.append(f'<a href="{root}{other}/{page_path}" hreflang="{code}" lang="{code}" title="{esc(ui("lang_title"))}" data-lang-switch>{label}</a>')
    return f'<nav class="lang-switch" aria-label="Language">{"".join(items)}</nav>'


def topbar(root: str, crumbs, page_path: str) -> str:
    crumb_html = "".join(
        (f'<a href="{u}">{esc(t)}</a>' if u else f'<span>{esc(t)}</span>') + ('<span class="sep">/</span>' if i < len(crumbs) - 1 else "")
        for i, (t, u) in enumerate(crumbs))
    return f'''<header class="topbar">
  <button class="icon-btn menu-btn" type="button" aria-label="{esc(ui("toggle_nav"))}" data-act="menu">{ICONS["menu"]}</button>
  <a class="brand" href="{root}index.html"><span class="brand-mark">N</span><span class="brand-text">{esc(ui("site_title"))}</span></a>
  <nav class="crumbs" aria-label="Breadcrumb">{crumb_html}</nav>
  <div class="top-actions">
    <div class="search" role="search">
      <span class="search-icon">{ICONS["search"]}</span>
      <input id="search-input" type="search" placeholder="{esc(ui("search_ph"))}" autocomplete="off" aria-label="{esc(ui("search_aria"))}">
      <div class="search-results" id="search-results" hidden></div>
    </div>
    {lang_switch(root, page_path)}
    <button class="icon-btn" type="button" data-act="width" title="{esc(ui("width_title"))}">{ICONS["width"]}<span class="btn-label" id="width-label">{esc(ui("width_wide"))}</span></button>
    <button class="icon-btn" type="button" data-act="theme" title="{esc(ui("theme_title"))}">{ICONS["theme"]}</button>
  </div>
</header>'''


def page_html(title: str, root: str, page_path: str, body: str, crumbs, side: str, toc_html: str = "", body_class: str = "") -> str:
    return f'''<!DOCTYPE html>
<html lang="{Ctx.lang}" data-width="wide">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<script>(function(){{try{{var d=document.documentElement,t=localStorage.getItem("nc-theme"),w=localStorage.getItem("nc-width");
if(t)d.setAttribute("data-theme",t);else if(window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches)d.setAttribute("data-theme","dark");
if(w)d.setAttribute("data-width",w);}}catch(e){{}}}})();</script>
<link rel="stylesheet" href="{root}assets/style.css">
</head>
<body class="{body_class}" data-root="{root}">
{topbar(root, crumbs, page_path)}
<div class="layout{" has-toc" if toc_html else ""}">
{side}
<main class="main" id="main">
{body}
</main>
{toc_html}
</div>
<div class="scrim" data-act="menu"></div>
<script src="{root}assets/app.js"></script>
</body>
</html>
'''


def toc_block(toc) -> str:
    if len(toc) < 2:
        return ""
    items = "".join(f'<li class="toc-{tag}"><a href="#{slug}">{esc(text)}</a></li>' for tag, slug, text in toc)
    return f'<aside class="toc" aria-label="{esc(ui("on_this_page"))}"><div class="toc-inner"><div class="toc-title">{esc(ui("on_this_page"))}</div><ol>{items}</ol></div></aside>'


def progress_bar(done: int, total: int) -> str:
    pct = round(100 * done / total) if total else 0
    return (f'<div class="progress" title="{esc(ui("progress_title", done=done, total=total))}"><div class="progress-track">'
            f'<div class="progress-fill" style="width:{pct}%"></div></div><span class="progress-text">{esc(ui("progress_text", done=done, total=total))}</span></div>')


# --------------------------------------------------------------------------------------
# Build
# --------------------------------------------------------------------------------------
def plain_text(h: str) -> str:
    h = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", h, flags=re.S)
    h = re.sub(r'<div class="code-head">.*?</div>', " ", h, flags=re.S)
    h = re.sub(r"<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", html.unescape(h)).strip()


def load_courses(data):
    courses = []
    for ci, (meta, contents) in enumerate(zip(data["lessons"], data["contents"])):
        chapter = meta["chapters"][0]
        by_id = {c["id"]: c for c in contents}
        name = meta["name"].strip()
        co = {"name": name, "title": plain(name), "dir": safe_filename(name), "lessons": [], "index": ci,
              "key": COURSE_KEYS[ci] if ci < len(COURSE_KEYS) else f"c{ci + 1}"}
        for li, lm in enumerate(chapter["lessons"], 1):
            nm = lm["name"].strip()
            kind = "Project" if lm.get("icon") == "project" else "Practice" if nm.lower().startswith("practice") else "Theory"
            co["lessons"].append({
                "id": lm["id"], "num": li, "name": nm, "title": plain(nm), "kind": kind,
                "key": f'{co["key"]}-{li:02d}',
                "passed": bool(lm.get("passed")), "current": bool(lm.get("current")),
                "file": f"{li:02d} - {safe_filename(nm)}.html", "content": by_id[lm["id"]], "course": co,
            })
        courses.append(co)
    return courses


def build_site(data, out: Path, lang: str, other_out: Path, img_dir: Path, slug_hints=None):
    """Build one language version of the site. Returns {lesson key: heading ids} for aligning other languages."""
    Ctx.lang = lang
    Ctx.translator = Translator(lang) if lang != "en" else None
    Ctx.collector = Collector() if lang == "en" else None
    Ctx.other_rel = os.path.relpath(other_out, out).replace(os.sep, "/")
    img_rel = os.path.relpath(img_dir, out).replace(os.sep, "/")
    Ctx.img_prefix = "../" + img_rel + "/"

    courses = load_courses(data)
    all_lessons = [l for co in courses for l in co["lessons"]]
    out.mkdir(parents=True, exist_ok=True)
    (out / "assets").mkdir(exist_ok=True)
    search_docs, report, slugs_out = [], {}, {}

    # ---- lesson bodies first (needed for read time, section previews and translation coverage)
    for l in all_lessons:
        if Ctx.collector:
            Ctx.collector.titles[l["key"]] = f'"{l["name"]}" ({l["course"]["name"]})'
        page = {"key": l["key"], "slugs": set(), "slug_order": [], "toc": [], "stats": {"callout": 0},
                "quizzes": 0, "units": 0, "missing": 0,
                "forced": deque((slug_hints or {}).get(l["key"], []))}
        Ctx.page = page
        l["html"] = render_node(l["content"]["theory"], page)
        Ctx.page = None
        l["toc"], l["quizzes"] = page["toc"], page["quizzes"]
        l["coverage"] = 1 if not page["units"] else (page["units"] - page["missing"]) / page["units"]
        l["missing"] = page["missing"]
        slugs_out[l["key"]] = page["slug_order"]
        text = plain_text(l["html"])
        l["minutes"] = max(1, round(len(text.split()) / 220))
        l["text"] = text
        for k, v in page["stats"].items():
            report[k] = report.get(k, 0) + v

    # ---- lesson pages
    for gi, l in enumerate(all_lessons):
        co, root = l["course"], "../"
        prev_l = all_lessons[gi - 1] if gi > 0 else None
        next_l = all_lessons[gi + 1] if gi + 1 < len(all_lessons) else None

        def nav_card(x, label, cls):
            if not x:
                return f'<span class="pn-card pn-empty {cls}"></span>'
            sub = x["course"]["title"] if x["course"] is not co else ui("lesson_n", n=x["num"])
            return (f'<a class="pn-card {cls}" href="{root}{href(x["course"]["dir"], x["file"])}" data-nav="{cls}">'
                    f'<span class="pn-label">{esc(label)}</span><span class="pn-title">{esc(x["title"])}</span>'
                    f'<span class="pn-sub">{esc(sub)}</span></a>')

        status = (f'<span class="pill pill-done">{ICONS["check"]} {esc(ui("completed"))}</span>' if l["passed"]
                  else f'<span class="pill pill-current">{esc(ui("you_are_here"))}</span>' if l["current"] else "")
        repo = l["content"].get("github_repo")
        reveal = (f'<button type="button" class="btn btn-small" data-act="reveal-all">{esc(ui("show_all_answers"))}</button>'
                  if l["quizzes"] else "")
        banner = ""
        if lang != "en" and l["missing"]:
            has_file = l["key"] in Ctx.translator.keys
            banner = f'<div class="tr-banner">{esc(ui("partly_translated") if has_file else ui("not_translated"))}</div>'
        quiz_meta = f'<span class="meta-item">{esc(count(l["quizzes"], "quiz"))}</span>' if l["quizzes"] else ""
        repo_meta = f'<span class="meta-item">{esc(ui("repo"))}: <code>{esc(repo)}</code></span>' if repo else ""
        header = f'''<header class="lesson-head">
  <a class="eyebrow" href="{root}{href(co["dir"], "index.html")}">{esc(co["title"])} · {esc(ui("lesson_x_of_y", n=l["num"], total=len(co["lessons"])))}</a>
  <h1>{esc(l["title"])}</h1>
  <div class="lesson-meta">{kind_badge(l)}<span class="meta-item">{esc(ui("min_read", n=l["minutes"]))}</span>
  {quiz_meta}{repo_meta}{status}{reveal}</div>
</header>{banner}'''
        body = (f'<article class="content lesson">{header}<div class="lesson-body">{l["html"]}</div>'
                f'<nav class="prev-next" aria-label="Lesson navigation">{nav_card(prev_l, ui("prev"), "prev")}{nav_card(next_l, ui("next"), "next")}</nav></article>')
        crumbs = [(ui("courses"), f"{root}index.html"), (co["title"], f'{root}{href(co["dir"], "index.html")}'), (l["title"], None)]
        doc = page_html(f'{l["title"]} · {co["title"]}', root, href(co["dir"], l["file"]), body, crumbs,
                        sidebar(courses, root, co, l), toc_block(l["toc"]), "page-lesson")
        (out / co["dir"]).mkdir(exist_ok=True)
        (out / co["dir"] / l["file"]).write_text(doc, encoding="utf-8")
        search_docs.append({"t": l["title"], "c": co["title"], "u": href(co["dir"], l["file"]), "k": l["kind"],
                            "h": [[s, txt] for _, s, txt in l["toc"]], "x": l["text"]})

    # ---- course pages
    for co in courses:
        root = "../"
        done = sum(l["passed"] for l in co["lessons"])
        cur = next((l for l in co["lessons"] if l["current"]), None) or next((l for l in co["lessons"] if not l["passed"]), None)
        cta_l = cur or co["lessons"][0]
        cta_label = ui("cta_continue") if (cur and done) else (ui("cta_start") if not done else ui("cta_review"))
        kinds = {k: sum(l["kind"] == k for l in co["lessons"]) for k in ("Theory", "Practice", "Project")}
        mins = sum(l["minutes"] for l in co["lessons"])
        rows = []
        for l in co["lessons"]:
            secs = " · ".join(esc(t) for tag, _, t in l["toc"] if tag == "h2")
            rows.append(
                f'<li class="lesson-row{" is-done" if l["passed"] else ""}{" is-current" if l["current"] else ""}">'
                f'<a href="{href(l["file"])}"><span class="row-num">{l["num"]:02d}</span>'
                f'<span class="row-main"><span class="row-title">{esc(l["title"])}{en_tag(l)}</span>'
                + (f'<span class="row-secs">{secs}</span>' if secs else "")
                + f'</span><span class="row-meta">{kind_badge(l)}<span class="row-time">{esc(ui("min", n=l["minutes"]))}</span>{status_mark(l)}</span></a></li>')
        body = f'''<article class="content course-page">
<header class="course-head">
  <div class="eyebrow">{esc(ui("course_x_of_y", n=co["index"] + 1, total=len(courses)))}</div>
  <h1>{esc(co["title"])}</h1>
  <div class="course-stats"><span>{esc(count(len(co["lessons"]), "lesson"))}</span><span>{esc(ui("theory_n", n=kinds["Theory"]))}</span>
  <span>{esc(ui("practice_n", n=kinds["Practice"] + kinds["Project"]))}</span><span>{esc(ui("hours_reading", h=num(round(mins / 60, 1))))}</span></div>
  {progress_bar(done, len(co["lessons"]))}
  <a class="btn btn-primary btn-cta" href="{href(cta_l["file"])}">{esc(cta_label)}: {esc(cta_l["title"])} →</a>
</header>
<ol class="lesson-list">{"".join(rows)}</ol>
</article>'''
        crumbs = [(ui("courses"), f"{root}index.html"), (co["title"], None)]
        doc = page_html(co["title"], root, href(co["dir"], "index.html"), body, crumbs, sidebar(courses, root, co, None), "", "page-course")
        (out / co["dir"] / "index.html").write_text(doc, encoding="utf-8")

    # ---- home page
    root = ""
    cards, tocs = [], []
    for co in courses:
        done = sum(l["passed"] for l in co["lessons"])
        cur = next((l for l in co["lessons"] if l["current"]), None)
        cont = (f'<a class="card-continue" href="{href(co["dir"], cur["file"])}">{esc(ui("continue_to", name=cur["title"]))}</a>' if cur else "")
        hours = num(round(sum(l["minutes"] for l in co["lessons"]) / 60, 1))
        cards.append(f'''<div class="course-card">
  <div class="card-num">{co["index"] + 1:02d}</div>
  <h2><a href="{href(co["dir"], "index.html")}">{esc(co["title"])}</a></h2>
  <div class="card-stats">{esc(count(len(co["lessons"]), "lesson"))} · {esc(count(sum(l["quizzes"] for l in co["lessons"]), "quiz"))} · {esc(ui("hours", h=hours))}</div>
  {progress_bar(done, len(co["lessons"]))}
  <div class="card-actions"><a class="btn btn-primary" href="{href(co["dir"], "index.html")}">{esc(ui("open_course"))}</a>{cont}</div>
</div>''')
        items = "".join(f'<li class="{"is-done" if l["passed"] else ""}{" is-current" if l["current"] else ""}">'
                        f'<a href="{href(co["dir"], l["file"])}">{status_mark(l)}<span class="side-num">{l["num"]}</span>'
                        f'<span>{esc(l["title"])}</span></a>{en_tag(l)}{kind_badge(l) if l["kind"] != "Theory" else ""}</li>'
                        for l in co["lessons"])
        tocs.append(f'<section class="home-toc-course"><h3><a href="{href(co["dir"], "index.html")}">{esc(co["title"])}</a></h3><ol>{items}</ol></section>')
    total_done = sum(l["passed"] for l in all_lessons)
    img_list = [img_rel + "/" + n for n in sorted(IMAGES.values())]
    lead = ui("home_lead", courses=esc(count(len(courses), "course")), lessons=esc(count(len(all_lessons), "lesson")),
              quizzes=esc(count(sum(l["quizzes"] for l in all_lessons), "quiz")))
    body = f'''<article class="content home">
<header class="home-head">
  <h1>{esc(ui("site_title"))}</h1>
  <p class="lead">{lead}</p>
  {progress_bar(total_done, len(all_lessons))}
  <div class="offline-status" data-images="{esc(json.dumps(img_list))}">
    <span class="offline-dot"></span><span class="offline-text">{esc(ui("checking_offline"))}</span>
  </div>
</header>
<div class="course-cards">{"".join(cards)}</div>
<h2 class="home-section-title">{esc(ui("all_lessons_title"))}</h2>
<div class="home-toc">{"".join(tocs)}</div>
</article>'''
    (out / "index.html").write_text(
        page_html(ui("site_title"), root, "index.html", body, [(ui("courses"), None)], sidebar(courses, root), "", "page-home"),
        encoding="utf-8")

    # ---- assets
    for f in ("style.css", "app.js"):
        shutil.copyfile(HERE / "static" / f, out / "assets" / f)

    def token_css(style, prefix):
        css = HtmlFormatter(style=style).get_style_defs(prefix)
        return "\n".join(ln for ln in css.splitlines() if ln.startswith(prefix + " .") and not ln.startswith(prefix + " .hll"))
    with open(out / "assets" / "style.css", "a", encoding="utf-8") as fh:
        fh.write("\n/* ---- syntax highlighting (generated by pygments) ---- */\n"
                 + token_css("default", ':root:not([data-theme="dark"]) .code pre') + "\n"
                 + token_css("github-dark", '[data-theme="dark"] .code pre') + "\n")
    (out / "assets" / "search-index.js").write_text(
        "window.SEARCH_INDEX=" + json.dumps(search_docs, ensure_ascii=False, separators=(",", ":")) + ";", encoding="utf-8")
    if lang == "en":
        write_image_downloader(out)
        Ctx.collector.write("ru")

    covered = sum(1 for l in all_lessons if l["coverage"] == 1)
    return courses, report, slugs_out, covered


def write_image_downloader(out: Path):
    """One-click Windows downloader: saves every lesson image into html/assets/img for offline reading."""
    (out / "assets" / "img").mkdir(parents=True, exist_ok=True)
    ps_q = lambda s: "'" + s.replace("'", "''") + "'"
    entries = "\n".join(f"    @{{ Name = {ps_q(n)}; Url = {ps_q(u)} }}" for u, n in sorted(IMAGES.items(), key=lambda x: x[1]))
    ps1 = f"""# Downloads all course images into assets\\img so the site can be read offline.
# Started by "Download images for offline use.bat". Safe to run again: existing files are skipped.
$ErrorActionPreference = 'Stop'
try {{ [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 }} catch {{ }}
try {{ [Net.WebRequest]::DefaultWebProxy.Credentials = [Net.CredentialCache]::DefaultNetworkCredentials }} catch {{ }}

$dest = Join-Path $PSScriptRoot 'img'
New-Item -ItemType Directory -Force -Path $dest | Out-Null

$images = @(
{entries}
)

$ok = 0; $skipped = 0; $failed = @(); $i = 0
foreach ($img in $images) {{
    $i++
    $file = Join-Path $dest $img.Name
    if ((Test-Path -LiteralPath $file) -and ((Get-Item -LiteralPath $file).Length -gt 0)) {{ $skipped++; continue }}
    Write-Host ("[{{0,2}}/{{1}}] {{2}}" -f $i, $images.Count, $img.Name)
    $tmp = $file + '.part'
    try {{
        $wc = New-Object System.Net.WebClient
        $wc.DownloadFile($img.Url, $tmp)
        Move-Item -LiteralPath $tmp -Destination $file -Force
        $ok++
    }} catch {{
        if (Test-Path -LiteralPath $tmp) {{ Remove-Item -LiteralPath $tmp -Force }}
        $failed += $img.Name
        Write-Host ("        failed: " + $_.Exception.Message) -ForegroundColor Red
    }}
}}

Write-Host ''
Write-Host ("Done. Downloaded: {{0}}   Already there: {{1}}   Failed: {{2}}" -f $ok, $skipped, $failed.Count) -ForegroundColor Cyan
if ($failed.Count -gt 0) {{
    Write-Host 'Some images failed. Check your internet connection and run the downloader again.' -ForegroundColor Yellow
    exit 1
}}
Write-Host 'All images are saved. The course pages now work without internet.' -ForegroundColor Green
"""
    (out / "assets" / "download-images.ps1").write_text(ps1.replace("\n", "\r\n"), encoding="ascii", newline="")
    bat = ("@echo off\r\n"
           "title Download course images for offline reading\r\n"
           "echo Downloading course images into the html\\assets\\img folder...\r\n"
           "echo.\r\n"
           "powershell -NoProfile -ExecutionPolicy Bypass -File \"%~dp0assets\\download-images.ps1\"\r\n"
           "echo.\r\n"
           "pause\r\n")
    (out / "Download images for offline use.bat").write_text(bat, encoding="ascii", newline="")


def build(src: Path, out_en: Path, out_ru: Path):
    data = json.loads(src.read_text(encoding="utf-8"))
    img_dir = out_en / "assets" / "img"
    courses, report, slugs, _ = build_site(data, out_en, "en", out_ru, img_dir)
    _, _, _, covered = build_site(data, out_ru, "ru", out_en, img_dir, slug_hints=slugs)
    return courses, report, covered


if __name__ == "__main__":
    src = Path(sys.argv[1] if len(sys.argv) > 1 else HERE.parent / "neb.json")
    out_en = Path(sys.argv[2] if len(sys.argv) > 2 else HERE.parent / "html")
    out_ru = Path(sys.argv[3] if len(sys.argv) > 3 else HERE.parent / "html-ru")
    courses, report, covered = build(src, out_en, out_ru)
    for co in courses:
        print(f'{co["dir"]}: {len(co["lessons"])} lessons')
    print("blocks rendered:", dict(sorted(report.items())))
    print(f"Russian: {covered} of {sum(len(c['lessons']) for c in courses)} lessons fully translated")
    print("sites written to", out_en, "and", out_ru)
