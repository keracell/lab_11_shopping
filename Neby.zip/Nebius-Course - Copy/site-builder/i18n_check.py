#!/usr/bin/env python3
"""
Check a lesson translation against its source.

    python3 i18n_check.py mcp-02            # Russian by default
    python3 i18n_check.py mcp-02 --lang ru

ERROR  = must be fixed (missing/extra/duplicate blocks, broken placeholders, empty text)
WARN   = review (inline code changed, table shape changed, block looks untranslated)
Exit code 1 if there are errors.
"""
import re
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
UNIT_SPLIT = re.compile(r"^@@@ ([0-9a-f]{10})[ \t]*$", re.M)
SLOT = re.compile(r"⟦[CIU]\d+⟧")
INLINE_CODE = re.compile(r"`[^`\n]+`")


def parse(text):
    parts = UNIT_SPLIT.split(text.replace("\r\n", "\n"))
    ids = [parts[i] for i in range(1, len(parts), 2)]
    return ids, {parts[i]: parts[i + 1].strip("\n").strip() for i in range(1, len(parts), 2)}


def table_shape(text):
    return [line.count("|") for line in text.splitlines() if line.strip().startswith("|")]


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    lang = sys.argv[sys.argv.index("--lang") + 1] if "--lang" in sys.argv else "ru"
    if not args:
        print(__doc__)
        return 2
    key = args[0]
    base = HERE / "translations" / lang
    src_ids, src = parse((base / "source" / f"{key}.txt").read_text(encoding="utf-8"))
    files = sorted((base / "lessons").glob(f"{key}.txt")) + sorted((base / "lessons").glob(f"{key}.part*.txt"))
    if not files:
        print(f"ERROR no translation file found: {base / 'lessons' / (key + '.txt')}")
        return 1
    tr_ids, tr = [], {}
    for f in files:
        ids, units = parse(f.read_text(encoding="utf-8"))
        tr_ids += ids
        tr.update(units)

    errors, warns = [], []
    dup = [i for i, n in Counter(tr_ids).items() if n > 1]
    if dup:
        errors.append(f"duplicate blocks: {', '.join(dup)}")
    missing = [i for i in src_ids if i not in tr]
    if missing:
        errors.append(f"{len(missing)} block(s) missing: {', '.join(missing[:15])}{' …' if len(missing) > 15 else ''}")
    extra = [i for i in tr if i not in src]
    if extra:
        errors.append(f"unknown block ids (not in source): {', '.join(extra[:15])}")
    order = [i for i in tr_ids if i in src]
    if order != [i for i in src_ids if i in tr]:
        warns.append("blocks are not in the same order as the source")

    for uid in src_ids:
        if uid not in tr:
            continue
        s, t = src[uid], tr[uid]
        if not t:
            errors.append(f"{uid}: empty translation")
            continue
        if sorted(SLOT.findall(s)) != sorted(SLOT.findall(t)):
            errors.append(f"{uid}: placeholders differ — source {sorted(SLOT.findall(s))} vs translation {sorted(SLOT.findall(t))}")
        if UNIT_SPLIT.search(t):
            errors.append(f"{uid}: contains an @@@ line inside the text")
        sc, tc = Counter(INLINE_CODE.findall(s)), Counter(INLINE_CODE.findall(t))
        if sc != tc:
            lost = list((sc - tc).elements())[:4]
            added = list((tc - sc).elements())[:4]
            warns.append(f"{uid}: inline code changed (missing {lost}, new {added})")
        if table_shape(s) != table_shape(t):
            warns.append(f"{uid}: table rows/columns differ from the source")
        letters = re.sub(r"`[^`]*`|⟦[^⟧]*⟧|\]\([^)]*\)", "", t)
        lat = len(re.findall(r"[A-Za-z]", letters))
        cyr = len(re.findall(r"[А-Яа-яЁё]", letters))
        if lat + cyr > 60 and cyr < 0.25 * (lat + cyr):
            warns.append(f"{uid}: looks mostly untranslated ({cyr} Cyrillic vs {lat} Latin letters)")
        if s.count("\n#") + s.startswith("#") != t.count("\n#") + t.startswith("#"):
            warns.append(f"{uid}: number of headings differs")

    total = len(src_ids)
    done = sum(1 for i in src_ids if tr.get(i))
    for e in errors:
        print("ERROR", e)
    for w in warns:
        print("WARN ", w)
    print(f"{key}: {done}/{total} blocks translated, {len(errors)} error(s), {len(warns)} warning(s)"
          f" — files: {', '.join(f.name for f in files)}")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
