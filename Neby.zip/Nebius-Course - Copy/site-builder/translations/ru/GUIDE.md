# Translating the Nebius course into Russian — guide for translators

You translate one lesson of an English technical course (AI agents, MCP servers, multi-agent systems)
into Russian for a Russian-speaking software engineer. The result is published as a static web page.

## Files

- Source: `translations/ru/source/<key>.txt` (for example `mcp-02.txt`).
- Your output: `translations/ru/lessons/<key>.txt`.
  For a big lesson you may split the output into several files: `<key>.txt`, `<key>.part2.txt`, `<key>.part3.txt` …
  Every block must be complete inside one file; together the files must cover every block of the source.
- Check: `python3 /home/claude/build/i18n_check.py <key>` — run it after writing, fix every ERROR, review every WARN.

## Format (strict)

The source is a list of blocks. Each block starts with a line `@@@ <10-character id>`.
Your output uses exactly the same blocks: the same `@@@ <id>` lines, in the same order, each followed by the
Russian translation of that block. The first lines of the source before the first `@@@` line are a header:
do not copy them (you may write one short header line of your own, or nothing).

```
@@@ b166b4e2da
📝 В этом уроке вы узнаете, что делает MCP-сервер, когда он нужен и сколько контекста модели он расходует.

@@@ 2086169e35
Поехали!
```

Never merge, split, skip or reorder blocks. Never change an id. Do not add notes or comments of your own.

## What must stay exactly as it is

- Placeholders `⟦C1⟧`, `⟦I2⟧`, `⟦U3⟧` … (code blocks, images, link addresses). Copy each one unchanged, keep it on its
  own line if it was on its own line, keep any indentation in front of it. Every placeholder must appear exactly once.
- Inline code in backticks: `` `SKILL.md` ``, `` `pr-label-format` ``, `` `uv run pytest` `` — copy unchanged, including the backticks.
- Markdown structure: headings (`##`, `###`), lists, numbering, tables (same number of rows and columns, keep the `|` and
  the `---` separator row), block quotes (`>`), bold/italic markers, line breaks, emojis at the start of lines.
- Link syntax: translate the visible link text, keep `](⟦U1⟧)` unchanged. If the link text is itself a URL or a file name, keep it.
- Names of products, libraries, protocols, commands, file names, environment variables, JSON keys, field names, model names,
  CLI flags and UI labels of English-only tools: Kiro, Claude Code, Cursor, Codex, Copilot, GitHub, MCP, FastMCP, MCP Inspector,
  LangGraph, LangSmith, LangChain, OpenTelemetry, Python, uv, pytest, JSON-RPC, stdio, Streamable HTTP, Slack, Jira, AGENTS.md …
- Text that is clearly a literal prompt, command, or message the learner must type into an English tool — keep it in English
  when the exact wording matters for the exercise (for example a prompt that a checker or the agent expects); otherwise translate it.
  When in doubt about a short example prompt in a block quote, translate it but keep any quoted identifiers.
- Numbers, versions, dates, IDs (`inc-4471`, `r_80349de5`), URLs.

## Style

- Natural, clear technical Russian, as in good Russian documentation (Habr, Yandex docs). Not word-for-word.
- Address the learner as «вы» (lower case). Keep the friendly, direct tone of the original; short sentences are fine.
- Use «ё» where it is normal (её, всё, ещё).
- Use Russian quotes «…» for ordinary quoted words; keep straight quotes inside code and inline code.
- Use the em dash « — » with spaces.
- Character names: Parisa → Париса, Marta → Марта, Kofi Mensah → Кофи Менса; other people's names — transliterate.
- Quiz options and feedback: translate faithfully and keep them short; do not make the right answer more obvious.
- Rubric / reviewer prompts (blocks that look like instructions for an AI reviewer): translate them too, but keep
  JSON keys, field names and output format tokens in English.
- Short UI-like texts: "Let's go!" → «Поехали!», "Learn more" → «Подробнее», "Got it" → «Понятно»,
  "✅ Submission checklist" → «✅ Чек-лист перед отправкой».

## Glossary (use consistently)

| English | Russian |
|---|---|
| AI agent / agent | ИИ-агент / агент |
| agentic | агентный |
| agency (level of autonomy) | агентность |
| LLM | LLM (большая языковая модель — при первом упоминании, если нужно) |
| model | модель |
| assistant, coding assistant | ассистент, ИИ-ассистент для программирования |
| prompt / system prompt | промпт / системный промпт |
| instructions | инструкции |
| context, context window | контекст, контекстное окно |
| token | токен |
| tool / tool call | инструмент / вызов инструмента |
| skill | навык (skill) — при первом упоминании в уроке, дальше «навык» |
| subagent | субагент |
| orchestrator / orchestration | оркестратор / оркестрация |
| hook | хук |
| memory (episodic, semantic) | память (эпизодическая, семантическая) |
| steering file | steering-файл |
| workflow | рабочий процесс (workflow) при первом упоминании; «workflow» как тип решения можно оставлять |
| automation | автоматизация |
| guardrails | ограничения (guardrails) при первом упоминании, дальше «ограничения» |
| publish gate | шлюз публикации (publish gate) |
| human-in-the-loop (HITL) | human-in-the-loop (участие человека) при первом упоминании |
| scope | рамки (задачи), область действия |
| Perceive → Reason → Act loop | цикл «Восприятие → Рассуждение → Действие» (Perceive → Reason → Act) |
| observability | наблюдаемость |
| telemetry / tracing / trace / span | телеметрия / трассировка / трасса / спан |
| log / logging | лог / логирование |
| output verification | проверка результата |
| MCP server / client / host | MCP-сервер / MCP-клиент / хост |
| transport | транспорт |
| resource / prompt (MCP primitives) | ресурс / промпт |
| surface (of a server/API) | поверхность (набор инструментов, ресурсов и промптов, которые сервер открывает) |
| contract | контракт |
| schema / input schema / output schema | схема / входная схема / выходная схема |
| structured content | структурированный контент (structuredContent) |
| state / stateful / stateless | состояние / с состоянием / без состояния |
| idempotent | идемпотентный |
| error handling | обработка ошибок |
| capability | возможность (capability) |
| elicitation / sampling / roots | elicitation / sampling / roots (термины MCP, не переводить; можно пояснить в скобках) |
| graph, node, edge, wiring | граф, узел, ребро, связи (подключение узлов) |
| checkpoint / checkpointer | чекпоинт / чекпоинтер |
| interrupt | прерывание (interrupt) |
| role decomposition | декомпозиция ролей |
| pull request (PR), merged PRs | пул-реквест (PR), смёрженные PR |
| release notes | заметки о релизе (release notes) |
| repository / commit / branch | репозиторий / коммит / ветка |
| runbook | ранбук (runbook) |
| incident / on-call | инцидент / дежурный (on-call) |
| deploy / deployment | деплой / развёртывание |
| practice task / submission | практическое задание / отправка решения |
| checklist | чек-лист |
| walkthrough | пошаговый разбор |
| takeaway(s) | главное / ключевые выводы |

Course and lesson titles are already translated (see `translations/ru/lessons/_titles.txt`); when the text mentions
another lesson by name, use that Russian title.
